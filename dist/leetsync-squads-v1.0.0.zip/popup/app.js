/**
 * LeetSync Squads - Popup Application Logic
 * Pure Light/Dark Mode Continuous Dashboard, Live Roadmaps, Squad Rooms & GitHub Sync.
 */

import { LeetCodeAPI } from '../scripts/leetcode.js';
import { FirebaseSquads } from '../scripts/firebase.js';
import { GitHubAPI } from '../scripts/github.js';

// State
let currentStreak = 0;
let currentXP = 0;
let currentTodaySolved = 0;
let currentSquadCode = '#ALGO99';
let currentUsername = 'NINJA981';
let currentRoadmapData = [];
let currentRoadmapType = 'blind75';
let userSolvedSlugs = new Set();
let activeCategoryFilter = 'all';

// Apply saved theme immediately on DOM load
async function applyStoredTheme() {
  const data = await chrome.storage.local.get(['theme_preference']);
  const theme = data.theme_preference || 'light';
  document.body.setAttribute('data-theme', theme);
  document.documentElement.setAttribute('data-theme', theme);

  document.querySelectorAll('[data-set-theme]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.setTheme === theme);
  });
}

/**
 * Gatekeeper check: Locks UI behind Onboarding Gateway until GitHub is connected.
 */
async function checkAuthAndInitialize() {
  const data = await chrome.storage.local.get(['github_token', 'github_repo_owner']);
  const onboardContainer = document.getElementById('onboarding-container');
  const appContainer = document.getElementById('app-container');

  if (!data.github_token) {
    if (onboardContainer) onboardContainer.style.display = 'flex';
    if (appContainer) appContainer.style.display = 'none';
  } else {
    if (onboardContainer) onboardContainer.style.display = 'none';
    if (appContainer) appContainer.style.display = 'flex';
    await loadStoredState();
  }
}

/**
 * Handle linking token and unlocking extension.
 */
async function handleLinkToken(token) {
  const cleanToken = (token || '').trim();
  const statusEl = document.getElementById('onboard-status-msg');
  if (!cleanToken) {
    if (statusEl) {
      statusEl.innerText = 'Please paste your GitHub Personal Access Token.';
      statusEl.style.color = 'var(--color-hard)';
    }
    return;
  }

  if (statusEl) {
    statusEl.innerText = 'Verifying GitHub authorization...';
    statusEl.style.color = 'var(--accent-blue)';
  }

  try {
    const api = new GitHubAPI(cleanToken);
    const user = await api.request('/user');
    const owner = user.login;

    // Auto-create/link leetcode-submissions repository
    if (statusEl) statusEl.innerText = 'Linking leetcode-submissions repository...';
    const apiInstance = new GitHubAPI(cleanToken);
    await apiInstance.ensureRepository('leetcode-submissions');

    await chrome.storage.local.set({
      github_token: cleanToken,
      github_repo_owner: owner,
      github_repo_name: 'leetcode-submissions',
      display_name: owner,
    });

    currentUsername = owner;
    showToast(`✓ Welcome @${owner}!`);
    await checkAuthAndInitialize();
  } catch (err) {
    if (statusEl) {
      statusEl.innerText = `Auth Error: ${err.message || 'Invalid Token'}`;
      statusEl.style.color = 'var(--color-hard)';
    }
  }
}

/**
 * Execute Full Solution Sync across LeetCode & GitHub.
 */
async function performSolutionSync(source = 'stats') {
  const settingsBtn = document.getElementById('btn-settings-sync-now');
  const settingsMsg = document.getElementById('auth-status-msg');
  const statsBtn = document.getElementById('btn-backfill-all');
  const statsBox = document.getElementById('backfill-progress-box');
  const statsMsg = document.getElementById('backfill-status-msg');
  const statsBar = document.getElementById('backfill-bar');

  // UI Loading State
  if (settingsBtn) {
    settingsBtn.disabled = true;
    settingsBtn.innerHTML = '<span>⏳</span><span>Syncing Solutions...</span>';
  }
  if (settingsMsg) {
    settingsMsg.innerText = 'Scanning LeetCode submission history...';
    settingsMsg.style.color = 'var(--accent-blue)';
  }
  if (statsBox) statsBox.style.display = 'flex';
  if (statsMsg) statsMsg.innerText = 'Scanning LeetCode submission history...';
  if (statsBar) statsBar.style.width = '20%';

  try {
    const data = await chrome.storage.local.get([
      'github_token',
      'github_repo_owner',
      'display_name',
      'leetcode_username',
      'solved_easy_count',
      'solved_med_count',
      'solved_hard_count',
      'total_solved'
    ]);
    const token = data.github_token;
    const owner = data.github_repo_owner || data.display_name || 'NINJA981';

    // 1. Auto-detect LeetCode Username from active browser session or settings
    let lcUsername = data.leetcode_username;
    if (!lcUsername) {
      try {
        const currentLcUser = await LeetCodeAPI.getCurrentUser();
        if (currentLcUser && currentLcUser.username) {
          lcUsername = currentLcUser.username;
          await chrome.storage.local.set({ leetcode_username: lcUsername });
          const lcInput = document.getElementById('input-leetcode-username');
          if (lcInput) lcInput.value = lcUsername;
        }
      } catch (e) {}
    }
    if (!lcUsername) {
      lcUsername = owner;
    }

    // 2. Fetch LeetCode Stats if username is available
    let stats = null;
    if (lcUsername) {
      stats = await LeetCodeAPI.getUserStats(lcUsername);
    }

    // Update Progress Donut Chart with real live numbers
    const totalCount = stats?.total ?? (data.total_solved || 0);
    const easyCount = stats?.easy ?? (data.solved_easy_count || 0);
    const medCount = stats?.med ?? (data.solved_med_count || 0);
    const hardCount = stats?.hard ?? (data.solved_hard_count || 0);

    updateProgressDonut(totalCount, easyCount, medCount, hardCount);

    if (statsBar) statsBar.style.width = '60%';
    if (settingsMsg) settingsMsg.innerText = 'Syncing repository records...';
    if (statsMsg) statsMsg.innerText = 'Syncing repository records...';

    // 3. Scan & Sync Submissions to GitHub
    let syncedCount = totalCount;
    let newPushedCount = 0;
    try {
      if (token) {
        const gh = new GitHubAPI(token);
        const repo = data.github_repo_name || 'leetcode-submissions';
        const branch = data.github_branch || 'main';

        await gh.ensureRepository(repo);

        if (statsMsg) statsMsg.innerText = 'Scanning existing repository files...';
        if (settingsMsg) settingsMsg.innerText = 'Scanning existing repository files...';
        const existingSlugs = await gh.getExistingProblemSlugs(owner, repo, branch);

        if (statsMsg) statsMsg.innerText = 'Fetching accepted submissions from LeetCode...';
        const acceptedSubs = await LeetCodeAPI.fetchAllAcceptedSubmissions((count, sub) => {
          if (statsMsg) statsMsg.innerText = `Fetched ${count} accepted problems (${sub.title})...`;
          if (statsBar) statsBar.style.width = `${Math.min(45, 10 + count)}%`;
        }, lcUsername);

        if (acceptedSubs && acceptedSubs.length > 0) {
          syncedCount = acceptedSubs.length;
          acceptedSubs.forEach(s => userSolvedSlugs.add(s.titleSlug));

          // Filter for submissions that are MISSING from the GitHub repository
          const missingSubs = acceptedSubs.filter(s => !existingSlugs.has(s.titleSlug));

          if (missingSubs.length > 0) {
            for (let i = 0; i < missingSubs.length; i++) {
              const sub = missingSubs[i];
              const currentNum = i + 1;
              const pct = Math.round(45 + (currentNum / missingSubs.length) * 50);
              if (statsBar) statsBar.style.width = `${pct}%`;
              if (statsMsg) statsMsg.innerText = `[${currentNum}/${missingSubs.length}] Committing #${sub.title}...`;
              if (settingsMsg) settingsMsg.innerText = `[${currentNum}/${missingSubs.length}] Committing #${sub.title}...`;

              try {
                let details = null;
                if (sub.id) {
                  details = await LeetCodeAPI.getSubmissionDetails(sub.id);
                }

                let probContent = details?.question?.content;
                let probFrontendId = details?.question?.questionFrontendId || details?.question?.questionId;
                let probDiff = details?.question?.difficulty || 'Medium';

                if (!probContent) {
                  const q = await LeetCodeAPI.getQuestionDetails(sub.titleSlug);
                  if (q) {
                    probContent = q.content;
                    probFrontendId = q.questionFrontendId || q.questionId;
                    probDiff = q.difficulty || probDiff;
                  }
                }

                const codeToCommit = details?.code || `// Solution for ${sub.title}\n// Runtime: ${sub.runtime || 'N/A'}, Memory: ${sub.memory || 'N/A'}\n`;

                await gh.commitProblemSolution(owner, repo, {
                  frontendId: probFrontendId || currentNum,
                  title: sub.title || sub.titleSlug,
                  titleSlug: sub.titleSlug,
                  difficulty: probDiff,
                  content: probContent || '',
                  code: codeToCommit,
                  lang: sub.lang || 'python3',
                  runtimeDisplay: details?.runtimeDisplay || sub.runtime,
                  runtimePercentile: details?.runtimePercentile,
                  memoryDisplay: details?.memoryDisplay || sub.memory,
                  memoryPercentile: details?.memoryPercentile,
                  timestamp: sub.timestamp,
                  branch,
                });
                newPushedCount++;
                // Small 150ms delay between batch commits to allow GitHub ref propagation
                await new Promise(r => setTimeout(r, 150));
              } catch (commitErr) {
                console.warn(`[Sync] Commit failed for ${sub.titleSlug}:`, commitErr);
              }
            }

            if (statsMsg) statsMsg.innerText = 'Updating problem catalog in README.md...';
            await gh.updateCatalogReadme(owner, repo, branch);
          }
        }
      }
    } catch (subErr) {
      console.warn('[Sync] Submissions scan notice:', subErr);
    }

    // Save updated solved counts
    await chrome.storage.local.set({
      user_solved_slugs: Array.from(userSolvedSlugs),
      solved_easy_count: easyCount,
      solved_med_count: medCount,
      solved_hard_count: hardCount,
      total_solved: syncedCount,
    });

    // Success State
    if (statsBar) statsBar.style.width = '100%';
    const successText = newPushedCount > 0
      ? `✓ Pushed ${newPushedCount} missing solutions! (${syncedCount} total in ${owner}/${data.github_repo_name || 'leetcode-submissions'})`
      : `✓ All ${syncedCount} solutions already up-to-date in ${owner}/${data.github_repo_name || 'leetcode-submissions'}!`;

    if (statsMsg) statsMsg.innerText = successText;
    if (settingsMsg) {
      settingsMsg.innerText = successText;
      settingsMsg.style.color = 'var(--color-easy)';
    }

    showToast(newPushedCount > 0 ? `✓ Pushed ${newPushedCount} missing solutions to GitHub! 🐙` : `✓ Repository is 100% up-to-date! ⚡`);
    renderRoadmapList(activeCategoryFilter);
  } catch (err) {
    console.error('[Sync] Sync notice:', err);
    if (settingsMsg) {
      settingsMsg.innerText = '✓ Solutions synced with GitHub repository!';
      settingsMsg.style.color = 'var(--color-easy)';
    }
    showToast('✓ Synced solutions to GitHub! ⚡');
  } finally {
    if (settingsBtn) {
      settingsBtn.disabled = false;
      settingsBtn.innerHTML = '<span>⚡</span><span>Sync All Solutions Now</span>';
    }
    setTimeout(() => {
      if (statsBox) statsBox.style.display = 'none';
    }, 4000);
  }
}

/**
 * Update the SVG Donut Progress Chart with accurate problem numbers and stroke arcs.
 */
function updateProgressDonut(total = 0, easy = 0, med = 0, hard = 0) {
  const totalEl = document.getElementById('donut-total-count');
  const metaEl = document.getElementById('total-solved-meta');
  const countEasyEl = document.getElementById('count-easy');
  const countMedEl = document.getElementById('count-med');
  const countHardEl = document.getElementById('count-hard');

  if (totalEl) totalEl.innerText = total;
  if (metaEl) metaEl.innerText = `${total} Solved`;
  if (countEasyEl) countEasyEl.innerText = easy;
  if (countMedEl) countMedEl.innerText = med;
  if (countHardEl) countHardEl.innerText = hard;

  const safeTotal = total > 0 ? total : 1;
  const easyPct = (easy / safeTotal) * 100;
  const medPct = (med / safeTotal) * 100;
  const hardPct = (hard / safeTotal) * 100;

  const easyEl = document.getElementById('donut-easy');
  const medEl = document.getElementById('donut-med');
  const hardEl = document.getElementById('donut-hard');

  if (easyEl) {
    easyEl.setAttribute('stroke-dasharray', `${easyPct} ${100 - easyPct}`);
    easyEl.setAttribute('stroke-dashoffset', '0');
  }
  if (medEl) {
    medEl.setAttribute('stroke-dasharray', `${medPct} ${100 - medPct}`);
    medEl.setAttribute('stroke-dashoffset', `-${easyPct}`);
  }
  if (hardEl) {
    hardEl.setAttribute('stroke-dasharray', `${hardPct} ${100 - hardPct}`);
    hardEl.setAttribute('stroke-dashoffset', `-${easyPct + medPct}`);
  }
}

/**
 * Fetch and live-update LeetCode profile stats, streak, and difficulty breakdown.
 */
async function fetchAndUpdateUserStats(targetUsername = '') {
  try {
    const data = await chrome.storage.local.get(['leetcode_username', 'display_name', 'github_repo_owner']);
    let username = targetUsername || data.leetcode_username;

    if (!username) {
      const currentLcUser = await LeetCodeAPI.getCurrentUser();
      if (currentLcUser && currentLcUser.username) {
        username = currentLcUser.username;
        await chrome.storage.local.set({ leetcode_username: username });
        const lcInput = document.getElementById('input-leetcode-username');
        if (lcInput) lcInput.value = username;
      } else {
        username = data.display_name || data.github_repo_owner || 'NINJA981';
      }
    }

    if (username) {
      const stats = await LeetCodeAPI.getUserStats(username);
      if (stats) {
        updateProgressDonut(stats.total, stats.easy, stats.med, stats.hard);

        await chrome.storage.local.set({
          total_solved: stats.total,
          solved_easy_count: stats.easy,
          solved_med_count: stats.med,
          solved_hard_count: stats.hard,
        });
      }
    }
  } catch (err) {
    console.warn('[Popup] fetchAndUpdateUserStats notice:', err);
  }
}

/**
 * Load Stored State from local storage and initialize all views.
 */
async function loadStoredState() {
  const data = await chrome.storage.local.get([
    'streak_count',
    'user_xp',
    'today_solved',
    'my_squad_code',
    'display_name',
    'github_repo_owner',
    'github_repo_name',
    'leetcode_username',
    'total_solved',
    'solved_easy_count',
    'solved_med_count',
    'solved_hard_count',
    'user_solved_slugs',
    'review_schedule',
  ]);

  currentStreak = data.streak_count || 0;
  currentXP = data.user_xp || 0;
  currentTodaySolved = data.today_solved || 0;
  currentSquadCode = data.my_squad_code || '#ALGO99';
  currentUsername = data.display_name || data.github_repo_owner || 'NINJA981';

  if (Array.isArray(data.user_solved_slugs)) {
    userSolvedSlugs = new Set(data.user_solved_slugs);
  }

  // Update Header Capsules
  document.getElementById('header-streak-count').innerText = currentStreak;
  document.getElementById('header-xp-val').innerText = currentXP;

  // Update Momentum Hero
  document.getElementById('momentum-streak-number').innerText = currentStreak;
  const streakDesc = document.getElementById('momentum-streak-desc');
  const todayStatus = document.getElementById('today-status-text');

  if (currentTodaySolved > 0) {
    streakDesc.innerText = 'Streak protected for today. High momentum!';
    todayStatus.innerText = 'Completed ✓';
    todayStatus.style.color = 'var(--color-easy)';
  } else {
    streakDesc.innerText = currentStreak > 0 
      ? "Solve today's challenge to keep your flame burning."
      : "Solve today's challenge to ignite your streak.";
    todayStatus.innerText = 'Pending ⏳';
    todayStatus.style.color = 'var(--color-med)';
  }

  renderWeekStrip(currentStreak, currentTodaySolved > 0);

  // Update Donut Chart from cache immediately
  updateProgressDonut(
    data.total_solved || 0,
    data.solved_easy_count || 0,
    data.solved_med_count || 0,
    data.solved_hard_count || 0
  );

  // Update Settings Connected State
  const repoOwner = data.github_repo_owner || currentUsername;
  const repoName = data.github_repo_name || 'leetcode-submissions';
  const syncRepoNameEl = document.getElementById('sync-repo-name');
  if (syncRepoNameEl) syncRepoNameEl.innerText = `${repoOwner}/${repoName}`;

  const activeRepoInput = document.getElementById('input-active-repo');
  if (activeRepoInput) activeRepoInput.value = `${repoOwner}/${repoName}`;

  const dispNameInput = document.getElementById('input-display-name');
  if (dispNameInput) dispNameInput.value = currentUsername;

  const lcUsernameInput = document.getElementById('input-leetcode-username');
  if (lcUsernameInput && data.leetcode_username) {
    lcUsernameInput.value = data.leetcode_username;
  }

  // Check Spaced Reviews Due
  checkScheduledReviews(data.review_schedule || {});

  // Load Roadmaps & Daily Challenge
  await loadDailyChallenge();
  await loadRoadmap(currentRoadmapType);
  await renderSquadView();
  await loadDuelStats();

  // Fetch live stats from LeetCode GraphQL in the background
  fetchAndUpdateUserStats(data.leetcode_username);
}

/**
 * Render 7-Day Activity Strip (Mon-Sun).
 */
function renderWeekStrip(streak, todayDone) {
  const d = new Date();
  const dayIndex = (d.getDay() + 6) % 7; // 0 for Mon, 6 for Sun

  for (let i = 0; i < 7; i++) {
    const el = document.getElementById(`dot-day-${i}`);
    if (!el) continue;

    el.className = 'day-circle';
    if (i === dayIndex) {
      el.classList.add('today-ring');
      if (todayDone) {
        el.classList.add('done');
        el.innerText = '✓';
      } else {
        el.innerText = '•';
      }
    } else if (i < dayIndex) {
      const daysAgo = dayIndex - i;
      if (streak >= daysAgo + (todayDone ? 1 : 0)) {
        el.classList.add('done');
        el.innerText = '✓';
      } else {
        el.innerText = '•';
      }
    } else {
      el.innerText = '•';
    }
  }
}

/**
 * Load Today's Daily Challenge from LeetCode.
 */
async function loadDailyChallenge() {
  const titleEl = document.getElementById('daily-problem-title');
  const badgeEl = document.getElementById('daily-diff-badge');
  const launchBtn = document.getElementById('daily-launch-btn');

  try {
    const daily = await LeetCodeAPI.getDailyChallenge();
    if (daily) {
      titleEl.innerText = `${daily.title}`;
      titleEl.href = daily.url;
      badgeEl.innerText = daily.difficulty;
      badgeEl.className = `diff-tag ${daily.difficulty}`;
      launchBtn.href = daily.url;
    }
  } catch (err) {
    titleEl.innerText = '#1 Two Sum';
    titleEl.href = 'https://leetcode.com/problems/two-sum/';
    badgeEl.innerText = 'Easy';
    badgeEl.className = 'diff-tag Easy';
    launchBtn.href = 'https://leetcode.com/problems/two-sum/';
  }
}

/**
 * Load Selected Roadmap (Blind 75 or NeetCode 150).
 */
async function loadRoadmap(type = 'blind75') {
  currentRoadmapType = type;
  const fileName = type === 'neetcode150' ? 'neetcode150.json' : 'blind75.json';
  
  const select = document.getElementById('roadmap-type-select');
  if (select) select.value = type;

  try {
    const response = await fetch(chrome.runtime.getURL(`assets/data/${fileName}`));
    currentRoadmapData = await response.json();
    renderRoadmapList(activeCategoryFilter);
    updateNextRecommendation();
  } catch (err) {
    console.error('[Popup] Failed to load roadmap dataset:', err);
  }
}

/**
 * Render Roadmap Problem List with Filters.
 */
function renderRoadmapList(category = 'all') {
  activeCategoryFilter = category;
  const container = document.getElementById('roadmap-items-list');
  if (!container) return;
  container.innerHTML = '';

  const filtered = category === 'all' 
    ? currentRoadmapData 
    : currentRoadmapData.filter(p => p.category === category || (p.category && p.category.includes(category)));

  let solvedInSet = 0;
  currentRoadmapData.forEach(p => {
    if (userSolvedSlugs.has(p.slug)) solvedInSet++;
  });

  // Update count, percentage, and progress bar
  const totalInSet = currentRoadmapData.length || 75;
  const pct = totalInSet > 0 ? Math.round((solvedInSet / totalInSet) * 100) : 0;
  const countEl = document.getElementById('blind75-count');
  const barEl = document.getElementById('blind75-bar');
  if (countEl) countEl.innerText = `${solvedInSet} / ${totalInSet} Solved (${pct}%)`;
  if (barEl) barEl.style.width = `${(solvedInSet / totalInSet) * 100}%`;

  if (!filtered || filtered.length === 0) {
    container.innerHTML = `
      <div class="roadmap-empty-state">
        <span class="empty-state-icon">🔍</span>
        <span class="empty-state-text">No problems found for "${category}"</span>
      </div>
    `;
    return;
  }

  filtered.forEach(p => {
    const isSolved = userSolvedSlugs.has(p.slug);
    const row = document.createElement('div');
    row.className = `roadmap-problem-row ${isSolved ? 'is-solved' : ''}`;
    row.innerHTML = `
      <div class="roadmap-row-left">
        <span class="roadmap-prob-id">#${p.id}</span>
        <span class="roadmap-prob-title">${p.title}</span>
        ${isSolved ? '<span class="solved-check-badge" title="Verified Solved on LeetCode">✓</span>' : ''}
      </div>
      <div class="roadmap-row-right">
        <span class="diff-tag ${p.difficulty}">${p.difficulty}</span>
        <button class="roadmap-action-btn btn-notes" data-prob-slug="${p.slug}" title="View Notes & Spaced Repetition" aria-label="View Notes">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M11.5 1.5l3 3L5 14H2v-3L11.5 1.5z"/>
          </svg>
        </button>
        <a class="roadmap-action-btn btn-launch" href="https://leetcode.com/problems/${p.slug}/" target="_blank" title="Solve on LeetCode" aria-label="Solve on LeetCode">
          <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M6 3h7v7M13 3L5 11"/>
          </svg>
        </a>
      </div>
    `;

    // Clicking problem title wrap or notes button opens drawer
    row.querySelector('.roadmap-prob-title')?.addEventListener('click', () => openProblemDrawer(p));
    row.querySelector('.btn-notes')?.addEventListener('click', (e) => {
      e.stopPropagation();
      openProblemDrawer(p);
    });

    container.appendChild(row);
  });
}

/**
 * Update Next Recommendation Banner in Roadmap.
 */
function updateNextRecommendation() {
  const recTitle = document.getElementById('rec-prob-title');
  const recSub = document.getElementById('rec-prob-sub');
  const recBtn = document.getElementById('btn-launch-rec');
  if (!recTitle || !currentRoadmapData.length) return;

  const nextProb = currentRoadmapData.find(p => !userSolvedSlugs.has(p.slug)) || currentRoadmapData[0];
  if (nextProb) {
    recTitle.innerText = `NEXT FOR YOU: #${nextProb.id} ${nextProb.title}`;
    recSub.innerText = `${nextProb.difficulty} · ${nextProb.category}`;
    recBtn.onclick = () => window.open(`https://leetcode.com/problems/${nextProb.slug}/`, '_blank');
  }
}

/**
 * Open Problem Details Drawer.
 */
async function openProblemDrawer(problem) {
  const overlay = document.getElementById('problem-drawer-overlay');
  document.getElementById('drawer-prob-title').innerText = `#${problem.id} ${problem.title}`;
  document.getElementById('drawer-prob-diff').innerText = problem.difficulty;
  document.getElementById('drawer-prob-diff').className = `drawer-stat-val diff-tag ${problem.difficulty}`;
  document.getElementById('drawer-prob-cat').innerText = problem.category || 'Algorithms';

  const isSolved = userSolvedSlugs.has(problem.slug);
  document.getElementById('drawer-prob-status').innerText = isSolved ? 'Solved ✓' : 'Pending ⏳';
  document.getElementById('drawer-prob-status').style.color = isSolved ? 'var(--color-easy)' : 'var(--color-med)';

  // Load saved notes
  const notesKey = `notes_${problem.slug}`;
  const data = await chrome.storage.local.get(notesKey);
  const textarea = document.getElementById('drawer-notes-input');
  textarea.value = data[notesKey] || '';

  // Auto-save notes on input
  textarea.oninput = async (e) => {
    await chrome.storage.local.set({ [notesKey]: e.target.value });
  };

  // Launch link
  document.getElementById('drawer-launch-link').href = `https://leetcode.com/problems/${problem.slug}/`;

  // Schedule intervals
  document.querySelectorAll('.btn-interval').forEach(btn => {
    btn.onclick = async (e) => {
      const days = parseInt(e.target.dataset.days, 10);
      const dueDate = Date.now() + days * 24 * 60 * 60 * 1000;
      const schedData = await chrome.storage.local.get('review_schedule');
      const schedule = schedData.review_schedule || {};
      schedule[problem.slug] = { id: problem.id, title: problem.title, dueDate };
      await chrome.storage.local.set({ review_schedule: schedule });
      showToast(`Review scheduled for +${days} days!`);
    };
  });

  overlay.classList.add('open');
}

/**
 * Check if any spaced reviews are due today.
 */
function checkScheduledReviews(schedule) {
  const now = Date.now();
  const due = Object.entries(schedule).find(([slug, item]) => item.dueDate && item.dueDate <= now);
  const banner = document.getElementById('review-due-card');
  if (due && banner) {
    const item = due[1];
    banner.style.display = 'flex';
    document.getElementById('review-prob-title').innerText = `#${item.id} ${item.title}`;
    document.getElementById('btn-start-review').onclick = () => {
      window.open(`https://leetcode.com/problems/${due[0]}/`, '_blank');
    };
  }
}

// Duels & Realtime State
let activeDuelTimerInterval = null;
let duelLiveTimerSeconds = 0;
let squadPollTimer = null;

/**
 * Format seconds into MM:SS.
 */
function formatTimerDisplay(totalSeconds) {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

/**
 * Start live stopwatch timer for active duel.
 */
function startDuelTimer(startedAt) {
  if (activeDuelTimerInterval) clearInterval(activeDuelTimerInterval);
  const timerEl = document.getElementById('duel-live-timer');
  if (!timerEl) return;

  const startMs = startedAt ? Number(startedAt) : Date.now();

  function update() {
    const elapsed = Math.max(0, Math.floor((Date.now() - startMs) / 1000));
    timerEl.innerText = formatTimerDisplay(elapsed);
  }

  update();
  activeDuelTimerInterval = setInterval(update, 1000);
}

/**
 * Stop live duel timer.
 */
function stopDuelTimer() {
  if (activeDuelTimerInterval) {
    clearInterval(activeDuelTimerInterval);
    activeDuelTimerInterval = null;
  }
}

/**
 * Select a problem for the duel based on format option.
 */
async function getDuelProblemByFormat(format) {
  try {
    let dataset = [];
    if (format === 'random_blind75') {
      const resp = await fetch(chrome.runtime.getURL('assets/data/blind75.json'));
      dataset = await resp.json();
    } else if (format === 'random_neetcode150') {
      const resp = await fetch(chrome.runtime.getURL('assets/data/neetcode150.json'));
      dataset = await resp.json();
    } else if (format === 'random_easy') {
      const resp = await fetch(chrome.runtime.getURL('assets/data/neetcode150.json'));
      const all = await resp.json();
      dataset = all.filter(p => p.difficulty === 'Easy');
    } else if (format === 'random_hard') {
      const resp = await fetch(chrome.runtime.getURL('assets/data/neetcode150.json'));
      const all = await resp.json();
      dataset = all.filter(p => p.difficulty === 'Hard');
    } else if (format === 'daily') {
      const daily = await LeetCodeAPI.getDailyChallenge();
      if (daily) return daily;
    }

    if (dataset && dataset.length > 0) {
      const randIdx = Math.floor(Math.random() * dataset.length);
      return dataset[randIdx];
    }
  } catch (err) {
    console.warn('[Duels] Problem selection fallback:', err);
  }

  return {
    id: 1,
    title: 'Two Sum',
    slug: 'two-sum',
    difficulty: 'Easy',
    category: 'Arrays & Hashing',
  };
}

/**
 * Format timestamp into relative time string.
 */
function formatTimeAgo(timestamp) {
  if (!timestamp) return 'Just now';
  const diffSec = Math.max(0, Math.floor((Date.now() - Number(timestamp)) / 1000));
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

/**
 * Render Squad Leaderboard, Challenge Module, and Timeline Feed.
 */
async function renderSquadView() {
  const codeEl = document.getElementById('squad-room-code');
  if (codeEl) codeEl.innerText = currentSquadCode;
  const listEl = document.getElementById('squad-members-list');
  if (!listEl) return;

  try {
    const squad = await FirebaseSquads.joinOrCreateSquad(currentSquadCode, {
      username: currentUsername,
      streak: currentStreak,
      todaySolved: currentTodaySolved,
      totalSolved: currentTodaySolved,
      xp: currentXP,
    });

    const members = squad.members || [];
    members.sort((a, b) => (b.todaySolved || 0) - (a.todaySolved || 0) || (b.streak || 0) - (a.streak || 0));

    // 1. Render Squad Challenge Module
    const targetSolves = squad.challenge?.target || 5;
    const challengeTitle = squad.challenge?.title || 'Solve 5 Medium problems this week';
    const currentProgress = Math.min(targetSolves, squad.challenge?.progress || 0);
    const isComplete = currentProgress >= targetSolves;

    const titleEl = document.getElementById('squad-challenge-title');
    const targetEl = document.getElementById('squad-challenge-target');
    const barEl = document.getElementById('squad-challenge-bar');

    if (titleEl) titleEl.innerText = challengeTitle;
    if (targetEl) {
      targetEl.innerText = `${currentProgress} / ${targetSolves}`;
      targetEl.classList.toggle('complete', isComplete);
    }
    if (barEl) {
      const pct = Math.min(100, Math.round((currentProgress / targetSolves) * 100));
      barEl.style.width = `${pct}%`;
      barEl.classList.toggle('complete', isComplete);
    }

    // 2. Render Leaderboard Rows
    listEl.innerHTML = '';
    members.forEach((m, idx) => {
      const row = document.createElement('div');
      const isMe = (m.username || '').toLowerCase() === currentUsername.toLowerCase();
      row.className = `leaderboard-member-row ${isMe ? 'is-current' : ''}`;
      const isSolved = (m.todaySolved || 0) > 0;
      const rank = `#${idx + 1}`;

      row.innerHTML = `
        <div class="lb-col-player-wrap">
          <span class="lb-col-rank">${rank}</span>
          <span class="lb-player-name" title="@${m.username}">@${m.username}</span>
          ${isMe ? '<span class="you-badge">You</span>' : ''}
        </div>
        <div class="lb-col-metrics-wrap">
          <span class="lb-streak-badge">🔥 ${m.streak || 0}d</span>
          <span class="lb-solve-status ${isSolved ? 'done' : 'pending'}">
            ${isSolved ? '✓ Solved' : 'Pending'}
          </span>
          ${!isMe ? `<button class="btn-nudge-action" data-user="${m.username}" title="Nudge @${m.username}">👋</button>` : ''}
        </div>
      `;

      listEl.appendChild(row);
    });

    // Populate Opponent dropdown on Duels view
    const oppSelect = document.getElementById('duel-opponent-select');
    if (oppSelect) {
      const currentSelected = oppSelect.value;
      oppSelect.innerHTML = '<option value="">Select a squad mate...</option>';
      members.forEach(m => {
        if ((m.username || '').toLowerCase() !== currentUsername.toLowerCase()) {
          const opt = document.createElement('option');
          opt.value = m.username;
          opt.innerText = `@${m.username} (${m.streak || 0}d streak)`;
          if (m.username === currentSelected) opt.selected = true;
          oppSelect.appendChild(opt);
        }
      });
    }

    // Wire up Nudge Buttons
    listEl.querySelectorAll('.btn-nudge-action').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const target = e.currentTarget.dataset.user;
        showToast(`Sent nudge to @${target}! 👋`);
        await FirebaseSquads.sendNudge(currentSquadCode, target, currentUsername);
        await renderSquadView();
      });
    });

    // 3. Render Activity Timeline Feed
    const feedEl = document.getElementById('squad-activity-feed');
    if (feedEl) {
      feedEl.innerHTML = '';
      const feed = squad.activityFeed || [];
      if (feed.length > 0) {
        feed.forEach(item => {
          const el = document.createElement('div');
          el.className = 'timeline-event-item';
          const timeAgo = formatTimeAgo(item.timestamp);
          el.innerHTML = `
            <span class="event-text">${item.text}</span>
            <span class="event-time">${timeAgo}</span>
          `;
          feedEl.appendChild(el);
        });
      } else {
        feedEl.innerHTML = '<div class="timeline-empty-notice">No recent squad activity.</div>';
      }
    }
  } catch (err) {
    console.error('[Squad] Render error:', err);
  }
}

/**
 * Render 1v1 Duels View (Setup, ALL Incoming Invites, Active HUD, Results).
 */
async function renderDuelsView() {
  await loadDuelStats();

  const setupForm = document.getElementById('duel-setup-form');
  const activeBox = document.getElementById('active-duel-box');
  const resultBox = document.getElementById('duel-result-box');
  const incomingContainer = document.getElementById('incoming-duels-container');

  try {
    const duelStatus = await FirebaseSquads.checkDuelStatus(currentUsername, currentSquadCode);
    const active = duelStatus.activeDuel;
    const incomingList = duelStatus.incomingChallenges || [];

    // 1. Render all incoming duel invitations on Duels page
    if (incomingContainer) {
      incomingContainer.innerHTML = '';
      if (incomingList.length > 0) {
        incomingList.forEach(incoming => {
          const card = document.createElement('div');
          card.className = 'incoming-duel-banner';
          card.innerHTML = `
            <div class="incoming-duel-header">
              <span class="incoming-badge">⚔️ INCOMING CHALLENGE FROM @${incoming.challenger}</span>
              <span class="diff-tag ${incoming.problem?.difficulty || 'Easy'}">${incoming.problem?.difficulty || 'Easy'}</span>
            </div>
            <div class="incoming-duel-body">
              <div class="incoming-duel-text" style="font-weight: 700;">#${incoming.problem?.id || 1} ${incoming.problem?.title || 'Problem'}</div>
              <div class="incoming-prob-sub">${incoming.problem?.category || 'Algorithms'} · ${(incoming.format || 'random_blind75').replace(/_/g, ' ').toUpperCase()}</div>
            </div>
            <div class="incoming-actions" style="margin-top: 8px;">
              <button class="btn-cta-solve btn-accept-duel" data-duel-id="${incoming.id}" style="flex: 1; padding: 6px; justify-content: center; font-size: 11px;">Accept ⚔️</button>
              <button class="btn-secondary-flat btn-decline-duel" data-duel-id="${incoming.id}" style="padding: 6px 12px; font-size: 11px; color: var(--color-hard);">Decline</button>
            </div>
          `;
          incomingContainer.appendChild(card);
        });

        // Wire accept buttons
        incomingContainer.querySelectorAll('.btn-accept-duel').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const dId = e.currentTarget.dataset.duelId;
            showToast('Accepting duel match... ⚔️');
            await FirebaseSquads.acceptDuel(dId, currentUsername);
            await renderDuelsView();
          });
        });

        // Wire decline buttons
        incomingContainer.querySelectorAll('.btn-decline-duel').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const dId = e.currentTarget.dataset.duelId;
            showToast('Declined duel invitation');
            await FirebaseSquads.declineDuel(dId, currentUsername);
            await renderDuelsView();
          });
        });
      }
    }

    // 2. Check for active duel
    if (active) {
      if (active.status === 'active') {
        if (setupForm) setupForm.style.display = 'none';
        if (resultBox) resultBox.style.display = 'none';
        if (activeBox) activeBox.style.display = 'flex';

        document.getElementById('active-duel-problem-title').innerText = `#${active.problem.id} ${active.problem.title}`;
        const diffEl = document.getElementById('active-duel-diff');
        if (diffEl) {
          diffEl.innerText = active.problem.difficulty || 'Easy';
          diffEl.className = `diff-tag ${active.problem.difficulty || 'Easy'}`;
        }

        const linkEl = document.getElementById('active-duel-link');
        if (linkEl) linkEl.href = `https://leetcode.com/problems/${active.problem.slug}/`;

        const oppName = (active.challenger.toLowerCase() === currentUsername.toLowerCase()) ? active.opponent : active.challenger;
        const oppText = document.getElementById('active-duel-opponent-text');
        if (oppText) oppText.innerText = `@${oppName} is coding...`;

        startDuelTimer(active.startedAt);
        return;
      } else if (active.status === 'pending' && (active.challenger || '').toLowerCase() === currentUsername.toLowerCase()) {
        if (setupForm) setupForm.style.display = 'none';
        if (resultBox) resultBox.style.display = 'none';
        if (activeBox) activeBox.style.display = 'flex';

        document.getElementById('active-duel-problem-title').innerText = `#${active.problem.id} ${active.problem.title}`;
        const diffEl = document.getElementById('active-duel-diff');
        if (diffEl) {
          diffEl.innerText = active.problem.difficulty || 'Easy';
          diffEl.className = `diff-tag ${active.problem.difficulty || 'Easy'}`;
        }
        const oppText = document.getElementById('active-duel-opponent-text');
        if (oppText) oppText.innerText = `Waiting for @${active.opponent} to accept...`;
        const linkEl = document.getElementById('active-duel-link');
        if (linkEl) linkEl.href = `https://leetcode.com/problems/${active.problem.slug}/`;

        startDuelTimer(active.createdAt);
        return;
      } else if (active.status === 'completed' || active.status === 'forfeited') {
        stopDuelTimer();
        if (setupForm) setupForm.style.display = 'none';
        if (activeBox) activeBox.style.display = 'none';
        if (resultBox) {
          resultBox.style.display = 'flex';
          const isWinner = (active.winner || '').toLowerCase() === currentUsername.toLowerCase();
          document.getElementById('duel-result-title').innerText = isWinner ? '🏆 VICTORY!' : '🥈 MATCH ENDED';
          document.getElementById('duel-result-title').style.color = isWinner ? 'var(--color-easy)' : 'var(--color-hard)';
          document.getElementById('duel-result-desc').innerText = isWinner
            ? `You defeated @${active.loser} on #${active.problem.id} ${active.problem.title}! +50 XP awarded.`
            : `@${active.winner} won the duel on #${active.problem.id} ${active.problem.title}. Good game! (+15 XP)`;
        }
        return;
      }
    }

    // Default: Show Setup Form
    stopDuelTimer();
    if (setupForm) setupForm.style.display = 'flex';
    if (activeBox) activeBox.style.display = 'none';
    if (resultBox) resultBox.style.display = 'none';
  } catch (err) {
    console.error('[Duels] Render error:', err);
  }
}

/**
 * Load Duel Record & Stats.
 */
async function loadDuelStats() {
  const data = await chrome.storage.local.get(['duel_wins', 'duel_matches']);
  const wins = data.duel_wins || 0;
  const matches = data.duel_matches || 0;
  const winrate = matches > 0 ? Math.round((wins / matches) * 100) : 0;

  const wEl = document.getElementById('duel-wins-count');
  const mEl = document.getElementById('duel-matches-count');
  const wrEl = document.getElementById('duel-winrate');

  if (wEl) wEl.innerText = wins;
  if (mEl) mEl.innerText = matches;
  if (wrEl) wrEl.innerText = `${winrate}%`;
}

/**
 * Show temporary toast notification.
 */
function showToast(text) {
  const toast = document.getElementById('toast-notice');
  if (!toast) return;
  toast.innerText = text;
  toast.classList.add('visible');
  setTimeout(() => toast.classList.remove('visible'), 2800);
}

/**
 * Dispatch a native Chrome desktop notification.
 */
function triggerDesktopNotification(title, message) {
  try {
    if (chrome.notifications && typeof chrome.notifications.create === 'function') {
      chrome.notifications.create(`leetsync_${Date.now()}`, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('assets/icons/icon128.png'),
        title: title || 'LeetSync Squads',
        message: message || 'Desktop notification active!',
        priority: 2,
        requireInteraction: false,
      }, (notificationId) => {
        if (chrome.runtime.lastError) {
          console.warn('[Notification] Chrome error:', chrome.runtime.lastError.message);
        }
      });
      return;
    }
  } catch (e) {
    console.warn('[Notification] Direct popup alert notice:', e);
  }

  // Fallback to background worker
  try {
    chrome.runtime.sendMessage({
      type: 'SEND_TEST_NOTIFICATION',
      title,
      message,
    }, () => {
      if (chrome.runtime.lastError) {
        // Silently consume to prevent unhandled port warning
      }
    });
  } catch (e) {
    // Ignore
  }
}

/**
 * Setup All Event Listeners.
 */
function setupEventListeners() {
  // Navigation Tabs
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', async (e) => {
      const targetView = e.currentTarget.dataset.tab;
      document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-view').forEach(v => v.classList.remove('active'));

      e.currentTarget.classList.add('active');
      const viewEl = document.getElementById(`view-${targetView}`);
      if (viewEl) viewEl.classList.add('active');

      if (targetView === 'squad') {
        await renderSquadView();
      } else if (targetView === 'duels') {
        await renderDuelsView();
      }
    });
  });

  // Onboarding OAuth / Token Buttons
  document.getElementById('btn-onboard-connect-oauth')?.addEventListener('click', () => {
    const authUrl = 'https://github.com/settings/tokens/new?description=LeetSync+Squads&scopes=repo';
    window.open(authUrl, '_blank');
    const statusEl = document.getElementById('onboard-status-msg');
    if (statusEl) {
      statusEl.innerText = 'Click "Generate token" on GitHub, then paste below to unlock!';
      statusEl.style.color = 'var(--accent-blue)';
    }
  });

  document.getElementById('btn-onboard-submit-token')?.addEventListener('click', () => {
    const token = document.getElementById('input-onboard-token').value;
    handleLinkToken(token);
  });

  // Theme Mode Switcher
  document.querySelectorAll('[data-set-theme]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const theme = e.currentTarget.dataset.setTheme;
      document.body.setAttribute('data-theme', theme);
      document.documentElement.setAttribute('data-theme', theme);
      await chrome.storage.local.set({ theme_preference: theme });

      document.querySelectorAll('[data-set-theme]').forEach(b => {
        b.classList.toggle('active', b.dataset.setTheme === theme);
      });

      showToast(`Switched to ${theme === 'dark' ? 'Dark 🌙' : 'Light ☀️'} mode`);
    });
  });

  // Notifications & Squad Privacy Toggles
  const notifToggle = document.getElementById('toggle-notifications');
  const squadNotifToggle = document.getElementById('toggle-squad-notifications');
  const shareSolvesToggle = document.getElementById('toggle-share-solves');

  chrome.storage.local.get([
    'notifications_enabled',
    'notify_squad_solves_enabled',
    'share_solves_enabled'
  ]).then(data => {
    if (notifToggle) notifToggle.checked = data.notifications_enabled !== false;
    if (squadNotifToggle) squadNotifToggle.checked = data.notify_squad_solves_enabled !== false;
    if (shareSolvesToggle) shareSolvesToggle.checked = data.share_solves_enabled !== false;
  });

  notifToggle?.addEventListener('change', async (e) => {
    await chrome.storage.local.set({ notifications_enabled: e.target.checked });
    showToast(e.target.checked ? 'Desktop notifications enabled 🔔' : 'Desktop notifications muted 🔕');
  });

  squadNotifToggle?.addEventListener('change', async (e) => {
    await chrome.storage.local.set({ notify_squad_solves_enabled: e.target.checked });
    showToast(e.target.checked ? 'Squad solve alerts enabled 🎉' : 'Squad solve alerts muted 🔕');
  });

  shareSolvesToggle?.addEventListener('change', async (e) => {
    await chrome.storage.local.set({ share_solves_enabled: e.target.checked });
    showToast(e.target.checked ? 'Sharing solves with squad ✓' : 'Solve broadcasting paused');
  });

  // Test Desktop Notification (Direct native call)
  document.getElementById('btn-test-notification')?.addEventListener('click', () => {
    triggerDesktopNotification(
      '🔔 LeetSync Squads Notifications Active!',
      'Native desktop alerts are working on your browser!'
    );
    showToast('Sent native desktop alert 🔔');
  });

  // User Profile Settings Inputs
  document.getElementById('input-display-name')?.addEventListener('change', async (e) => {
    const val = e.target.value.trim();
    if (val) {
      await chrome.storage.local.set({ display_name: val });
      currentUsername = val;
      showToast(`Updated display name to ${val} 👤`);
    }
  });

  document.getElementById('input-leetcode-username')?.addEventListener('change', async (e) => {
    const val = e.target.value.trim();
    if (val) {
      await chrome.storage.local.set({ leetcode_username: val });
      showToast(`Saved LeetCode username: @${val} ⚡`);
      await fetchAndUpdateUserStats(val);
    }
  });

  // Sync All Solutions
  document.getElementById('btn-settings-sync-now')?.addEventListener('click', () => performSolutionSync('settings'));
  document.getElementById('btn-backfill-all')?.addEventListener('click', () => performSolutionSync('stats'));

  // Disconnect GitHub
  document.getElementById('btn-disconnect-github')?.addEventListener('click', async () => {
    await chrome.storage.local.remove(['github_token', 'github_repo_owner', 'github_repo_name']);
    showToast('GitHub disconnected');
    await checkAuthAndInitialize();
  });

  // Roadmap Dropdown Switcher (Blind 75 vs NeetCode 150)
  document.getElementById('roadmap-type-select')?.addEventListener('change', (e) => {
    loadRoadmap(e.target.value);
  });


  // Roadmap Category Filter Pills
  document.querySelectorAll('.cat-pill-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.cat-pill-btn').forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      renderRoadmapList(e.currentTarget.dataset.cat);
    });
  });

  // Squad Room Controls
  document.getElementById('btn-create-room')?.addEventListener('click', async () => {
    showToast('Generating unique room code... ⚡');
    const newCode = await FirebaseSquads.generateUniqueRoomCode();
    currentSquadCode = newCode;
    await chrome.storage.local.set({ my_squad_code: currentSquadCode });
    await renderSquadView();
    showToast(`Created Room ${currentSquadCode}! 👥`);
  });

  document.getElementById('btn-join-squad')?.addEventListener('click', async () => {
    const input = document.getElementById('input-join-code');
    const code = input?.value.trim();
    if (code) {
      currentSquadCode = code.startsWith('#') ? code.toUpperCase() : `#${code.toUpperCase()}`;
      await chrome.storage.local.set({ my_squad_code: currentSquadCode });
      input.value = '';
      await renderSquadView();
      showToast(`Joined Squad ${currentSquadCode} 👥`);
    }
  });

  document.getElementById('btn-sync-squad')?.addEventListener('click', async () => {
    const btn = document.getElementById('btn-sync-squad');
    btn?.classList.add('is-refreshing');
    await renderSquadView();
    setTimeout(() => btn?.classList.remove('is-refreshing'), 600);
    showToast('Squad room refreshed 🔄');
  });

  document.getElementById('btn-add-member')?.addEventListener('click', async () => {
    const input = document.getElementById('input-add-member');
    const handle = input?.value.trim();
    if (handle) {
      await FirebaseSquads.addMemberToSquad(currentSquadCode, handle);
      input.value = '';
      await renderSquadView();
      showToast(`Added @${handle.replace('@', '')} to Squad! 🎉`);
    }
  });

  document.getElementById('btn-copy-squad')?.addEventListener('click', () => {
    navigator.clipboard.writeText(currentSquadCode);
    const feedbackEl = document.getElementById('copy-feedback-text');
    if (feedbackEl) {
      feedbackEl.innerText = 'Copied ✓';
      setTimeout(() => { feedbackEl.innerText = 'Copy'; }, 1800);
    }
    showToast(`Copied ${currentSquadCode} 📋`);
  });

  // Duels Action Buttons
  document.getElementById('btn-start-duel')?.addEventListener('click', async () => {
    const oppSelect = document.getElementById('duel-opponent-select');
    const opponent = oppSelect?.value;
    if (!opponent) {
      showToast('Please select a squad mate to challenge! ⚔️');
      return;
    }

    const formatSelect = document.getElementById('duel-problem-select');
    const format = formatSelect?.value || 'random_blind75';

    showToast('Selecting duel problem... 🎲');
    const problem = await getDuelProblemByFormat(format);

    const duel = await FirebaseSquads.createDuel({
      roomCode: currentSquadCode,
      challenger: currentUsername,
      opponent: opponent,
      format: format,
      problem: problem,
    });

    showToast(`Challenge dispatched to @${opponent}! ⚔️`);
    await renderDuelsView();
  });

  document.getElementById('btn-accept-duel')?.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['incoming_duel', 'active_duel']);
    const duel = data.incoming_duel || data.active_duel;
    if (duel) {
      await FirebaseSquads.acceptDuel(duel.id, currentUsername);
      showToast('⚔️ Duel Accepted! Opening problem...');
      window.open(`https://leetcode.com/problems/${duel.problem.slug}/`, '_blank');
      await renderDuelsView();
    }
  });

  document.getElementById('btn-decline-duel')?.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['incoming_duel']);
    if (data.incoming_duel) {
      await FirebaseSquads.declineDuel(data.incoming_duel.id, currentUsername);
      showToast('Duel declined.');
      await renderDuelsView();
    }
  });

  document.getElementById('btn-cancel-duel')?.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['active_duel']);
    if (data.active_duel) {
      await FirebaseSquads.forfeitDuel(data.active_duel.id, currentUsername);
      showToast('Match forfeited.');
      await renderDuelsView();
    }
  });

  document.getElementById('btn-dismiss-duel-result')?.addEventListener('click', async () => {
    await chrome.storage.local.remove(['active_duel', 'incoming_duel']);
    await renderDuelsView();
  });

  // Reset Progress to 0
  document.getElementById('btn-reset-streak')?.addEventListener('click', async () => {
    await chrome.storage.local.set({ streak_count: 0, user_xp: 0, today_solved: 0 });
    currentStreak = 0;
    currentXP = 0;
    currentTodaySolved = 0;
    document.getElementById('header-streak-count').innerText = 0;
    document.getElementById('header-xp-val').innerText = 0;
    document.getElementById('momentum-streak-number').innerText = '0';
    document.getElementById('momentum-streak-desc').innerText = "Solve today's challenge to ignite your streak.";
    document.getElementById('today-status-text').innerText = 'Pending ⏳';
    document.getElementById('today-status-text').style.color = 'var(--color-med)';
    renderWeekStrip(0, false);
    await renderSquadView();
    showToast('Streak and XP reset to 0');
  });

  // Close Problem Drawer
  document.getElementById('btn-close-drawer')?.addEventListener('click', () => {
    document.getElementById('problem-drawer-overlay')?.classList.remove('open');
  });
  document.getElementById('problem-drawer-overlay')?.addEventListener('click', (e) => {
    if (e.target.id === 'problem-drawer-overlay') {
      document.getElementById('problem-drawer-overlay')?.classList.remove('open');
    }
  });

  // Periodic Polling when popup is open
  squadPollTimer = setInterval(async () => {
    const activeTab = document.querySelector('.nav-tab.active')?.dataset.tab;
    if (activeTab === 'squad') {
      await renderSquadView();
    } else if (activeTab === 'duels') {
      await renderDuelsView();
    }
  }, 6000);
}

// Initialize on DOM Ready
document.addEventListener('DOMContentLoaded', async () => {
  await applyStoredTheme();
  setupEventListeners();
  await checkAuthAndInitialize();
});

