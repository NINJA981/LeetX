
/**
 * Send Chrome Native Desktop Notification if enabled.
 */
async function sendDesktopNotification(title, message, notificationId = null) {
  try {
    const data = await chrome.storage.local.get(['notifications_enabled']);
    const isEnabled = data.notifications_enabled !== false; // Default true

    if (!isEnabled) return;

    // 1. Dispatch Native Chrome / Windows Desktop Notification
    if (chrome.notifications && typeof chrome.notifications.create === 'function') {
      const notifOptions = {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('assets/icons/icon128.png'),
        title: title || 'LeetSync Squads',
        message: message || '',
        priority: 2,
        requireInteraction: false,
      };

      chrome.notifications.create(notificationId || `leetsync_${Date.now()}`, notifOptions, (id) => {
        if (chrome.runtime.lastError) {
          console.warn('[Notifications] Error creating desktop alert:', chrome.runtime.lastError.message);
        }
      });
    }

    // 2. Broadcast in-page banner to active LeetCode tabs
    if (chrome.tabs && typeof chrome.tabs.query === 'function') {
      chrome.tabs.query({ url: '*://*.leetcode.com/*' }, (tabs) => {
        if (tabs && tabs.length > 0) {
          tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, {
              type: 'SHOW_INPAGE_NOTIFICATION',
              title,
              message,
            }, () => {
              if (chrome.runtime.lastError) { /* ignore tabs without script */ }
            });
          });
        }
      });
    }
  } catch (err) {
    console.warn('[Notifications] Dispatch notice:', err.message);
  }
}

/**
 * LeetSync Squads - Manifest V3 Background Service Worker
 * Coordinates live streak tracking, problem solves, alarms, and toolbar badge.
 */

import { GitHubAPI } from './github.js';
import { LeetCodeAPI } from './leetcode.js';
import { FirebaseSquads } from './firebase.js';

function getTodayDateStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function getYesterdayDateStr() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// On first install, initialize fresh streak and XP to 0
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await chrome.storage.local.set({
      streak_count: 0,
      user_xp: 0,
      today_solved: 0,
      last_solved_date: null,
      notifications_enabled: true,
      notify_squad_solves_enabled: true,
      share_solves_enabled: true,
    });
  }
  chrome.alarms.create('daily_streak_check', { periodInMinutes: 60 });
  chrome.alarms.create('squad_presence_poll', { periodInMinutes: 1 });
  await updateDailyStreakState();
  await checkIncomingSquadEvents();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'daily_streak_check') {
    await updateDailyStreakState();
  } else if (alarm.name === 'squad_presence_poll') {
    await checkIncomingSquadEvents();
  }
});

// When a desktop notification is clicked, route to the Duels page
if (chrome.notifications && chrome.notifications.onClicked) {
  chrome.notifications.onClicked.addListener(async (notificationId) => {
    await chrome.storage.local.set({ target_open_tab: 'duels' });
    chrome.notifications.clear(notificationId);

    if (chrome.action && typeof chrome.action.openPopup === 'function') {
      try {
        await chrome.action.openPopup();
      } catch (e) {
        // Handled silently
      }
    }
  });
}

/**
 * Daily date rollover check (resets today's solve count, checks if streak broke).
 */
async function updateDailyStreakState() {
  const data = await chrome.storage.local.get(['streak_count', 'today_solved', 'last_solved_date']);
  const today = getTodayDateStr();
  const yesterday = getYesterdayDateStr();

  let streak = data.streak_count || 0;
  let todaySolved = data.today_solved || 0;
  const lastDate = data.last_solved_date;

  if (lastDate) {
    if (lastDate !== today && lastDate !== yesterday) {
      // Missed more than 1 day -> streak reset to 0
      streak = 0;
      todaySolved = 0;
    } else if (lastDate === yesterday) {
      // New day started -> waiting for today's solve
      todaySolved = 0;
    }
  } else {
    streak = 0;
    todaySolved = 0;
  }

  await chrome.storage.local.set({ streak_count: streak, today_solved: todaySolved });
  updateToolbarBadge(streak, todaySolved);
}

/**
 * Update the extension toolbar icon badge with current streak.
 */
function updateToolbarBadge(streak, todaySolved) {
  const text = streak > 0 ? (todaySolved > 0 ? `✓${streak}` : `${streak}`) : '';
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({
    color: todaySolved > 0 ? '#10B981' : '#F59E0B',
  });
}

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PROBLEM_SOLVED' || message.type === 'SYNC_SUBMISSION') {
    const solveData = message.data || {
      slug: message.titleSlug,
      title: message.titleSlug ? message.titleSlug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'Problem',
      difficulty: 'Medium',
      submissionId: message.submissionId,
    };
    handleProblemSolved(solveData)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // async response
  }

  if (message.type === 'CHECK_DUEL_INVITES' || message.type === 'POLL_SQUAD_EVENTS') {
    checkIncomingSquadEvents()
      .then(res => sendResponse(res || { success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === 'SEND_TEST_NOTIFICATION') {
    const title = message.title || '🔔 LeetSync Squads Notifications Active!';
    const body = message.message || 'Desktop notifications are enabled and working properly on your browser.';
    sendDesktopNotification(title, body)
      .then(() => sendResponse({ success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === 'GITHUB_OAUTH_LOGIN') {
    sendResponse({ success: false, error: 'Please enter your GitHub Personal Access Token below.' });
    return true;
  }
});

/**
 * Check for incoming squad events (1v1 duels, nudges, member solves) and dispatch desktop notifications.
 */
async function checkIncomingSquadEvents() {
  try {
    const data = await chrome.storage.local.get([
      'my_squad_code',
      'display_name',
      'github_repo_owner',
      'last_seen_activity_id',
      'notifications_enabled',
      'notify_squad_solves_enabled'
    ]);

    if (data.notifications_enabled === false) return;

    const username = data.display_name || data.github_repo_owner || 'NINJA981';
    const roomCode = data.my_squad_code || '#ALGO99';

    const squad = await FirebaseSquads.fetchRemoteSquad(roomCode);
    if (!squad || !Array.isArray(squad.activityFeed) || squad.activityFeed.length === 0) return;

    const lastSeenId = data.last_seen_activity_id;
    const newEvents = [];
    for (const act of squad.activityFeed) {
      if (act.id === lastSeenId) break;
      newEvents.push(act);
    }

    if (newEvents.length > 0) {
      await chrome.storage.local.set({ last_seen_activity_id: squad.activityFeed[0].id });

      for (const act of newEvents) {
        const text = (act.text || '').toLowerCase();
        const userLower = username.toLowerCase();

        // 1. Duel challenge targeted at you
        if (act.type === 'duel_challenge' && text.includes(`@${userLower}`)) {
          await sendDesktopNotification('⚔️ 1v1 Duel Challenge!', act.text || 'A squad mate challenged you to a 1v1 Duel race!');
        }
        // 2. Squad nudge targeted at you
        else if (act.type === 'nudge' && text.includes(`@${userLower}`)) {
          await sendDesktopNotification('👋 Squad Nudge!', act.text || 'A squad mate nudged you to solve today\'s problem!');
        }
        // 3. Squad solve by someone else
        else if (act.type === 'solve' && !text.startsWith(`@${userLower}`) && data.notify_squad_solves_enabled !== false) {
          await sendDesktopNotification('🎉 Squad Mate Solved a Problem!', act.text || 'A squad member just completed a problem!');
        }
      }
    }
  } catch (err) {
    console.warn('[Background] Squad event poll notice:', err);
  }
}

/**
 * Handle live problem solve: increment dynamic streak, XP, and sync to GitHub & Firebase.
 */
async function handleProblemSolved(solveData) {
  const today = getTodayDateStr();
  const yesterday = getYesterdayDateStr();

  const data = await chrome.storage.local.get([
    'streak_count',
    'today_solved',
    'user_xp',
    'last_solved_date',
    'github_token',
    'github_repo_owner',
    'github_repo_name',
    'github_branch',
    'my_squad_code',
    'display_name',
    'user_solved_slugs',
    'active_duel',
  ]);

  let streak = data.streak_count || 0;
  let todaySolved = data.today_solved || 0;
  let xp = data.user_xp || 0;
  const lastDate = data.last_solved_date;

  const diffXp = solveData.difficulty === 'Hard' ? 50 : (solveData.difficulty === 'Medium' ? 25 : 10);
  xp += diffXp;

  if (lastDate === today) {
    todaySolved += 1;
  } else if (lastDate === yesterday || !lastDate || streak === 0) {
    streak += 1;
    todaySolved = 1;
  }

  // Update solved slugs list
  const solvedSlugs = new Set(data.user_solved_slugs || []);
  if (solveData.slug) solvedSlugs.add(solveData.slug);

  await chrome.storage.local.set({
    streak_count: streak,
    today_solved: todaySolved,
    user_xp: xp,
    last_solved_date: today,
    user_solved_slugs: Array.from(solvedSlugs),
  });

  updateToolbarBadge(streak, todaySolved);

  const username = data.display_name || data.github_repo_owner || 'NINJA981';
  const squadCode = data.my_squad_code || '#ALGO99';

  // 1. Sync to Firebase Squad Room
  try {
    await FirebaseSquads.broadcastSolve(squadCode, username, solveData, streak);
  } catch (e) {
    console.warn('[Background] Firebase broadcast notice:', e.message);
  }

  // 2. Live Sync Solution to GitHub Repository
  let gitHubSynced = false;
  if (data.github_token) {
    try {
      const gh = new GitHubAPI(data.github_token);
      const owner = data.github_repo_owner || data.display_name || 'NINJA981';
      const repo = data.github_repo_name || 'leetcode-submissions';
      const branch = data.github_branch || 'main';

      await gh.ensureRepository(repo);

      // Fetch submission details from LeetCode GraphQL
      let details = null;
      if (solveData.submissionId) {
        details = await LeetCodeAPI.getSubmissionDetails(solveData.submissionId);
      }

      if (details && details.code) {
        await gh.commitProblemSolution(owner, repo, {
          frontendId: details.question?.questionFrontendId || details.question?.questionId || solveData.id || 1,
          title: details.question?.title || solveData.title || 'Problem',
          titleSlug: details.question?.titleSlug || solveData.slug || 'problem',
          difficulty: details.question?.difficulty || solveData.difficulty || 'Medium',
          content: details.question?.content || '',
          code: details.code,
          lang: details.lang?.name || 'python3',
          runtimeDisplay: details.runtimeDisplay,
          runtimePercentile: details.runtimePercentile,
          memoryDisplay: details.memoryDisplay,
          memoryPercentile: details.memoryPercentile,
          timestamp: details.timestamp || Math.floor(Date.now() / 1000),
          branch,
        });

        await gh.updateCatalogReadme(owner, repo, branch);
        gitHubSynced = true;
      }
    } catch (ghErr) {
      console.warn('[Background] Live GitHub commit notice:', ghErr.message);
    }
  }

  // 3. Check if this solve completes an active 1v1 Duel Match
  let duelWin = false;
  let activeDuel = data.active_duel;

  if (!activeDuel || activeDuel.status !== 'active') {
    try {
      const duelStatus = await FirebaseSquads.checkDuelStatus(username, squadCode);
      if (duelStatus.activeDuel && duelStatus.activeDuel.status === 'active') {
        activeDuel = duelStatus.activeDuel;
      }
    } catch (statusErr) {
      console.warn('[Background] Duel status check fallback notice:', statusErr);
    }
  }

  if (activeDuel && activeDuel.status === 'active') {
    const duel = activeDuel;
    const duelSlug = (duel.problem?.slug || '').toLowerCase().trim();
    const solveSlug = (solveData.slug || solveData.titleSlug || '').toLowerCase().trim();

    if (duelSlug && solveSlug && (duelSlug === solveSlug || duelSlug.includes(solveSlug) || solveSlug.includes(duelSlug))) {
      try {
        await FirebaseSquads.submitDuelSolve(duel.id, username, solveData);
        duelWin = true;
        await sendDesktopNotification(
          '🏆 1v1 DUEL VICTORY!',
          `You solved #${duel.problem.id} ${duel.problem.title} before your opponent! (+50 XP)`
        );
      } catch (err) {
        console.warn('[Background] Duel submit solve notice:', err);
      }
    }
  }

  // 4. Desktop solve notification
  if (!duelWin) {
    const notifTitle = gitHubSynced ? '⚡ Problem Synced to GitHub!' : '⚡ Problem Accepted!';
    const notifMsg = gitHubSynced
      ? `#${solveData.id || ''} ${solveData.title || 'Solution'} committed with authentic metrics! 🔥 Streak: ${streak}d`
      : `#${solveData.id || ''} ${solveData.title || 'Solution'} recorded! 🔥 Streak: ${streak}d`;

    await sendDesktopNotification(notifTitle, notifMsg);
  }

  return { success: true, streak, xp, todaySolved, duelWin, gitHubSynced };
}


